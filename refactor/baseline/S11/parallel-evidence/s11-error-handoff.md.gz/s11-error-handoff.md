# S11 通用错误与 Anthropic API Key 直通交接

## 生产调用

- service/gateway_upstream_response.go 的 handleErrorResponse、handleRetryExhaustedError 已委托 gateway/forward.AnthropicError / AnthropicRetryError。
- 匹配使用 app 已有唯一 gateway/errorpolicy 实例的 MatchRule；新核心仅解释本协议的响应动作。顺序保留账号健康 → 通用错误/显式 failover → 提交标记 → 展示规则 → 原默认消息/原始 400。默认安全消息、错误字符串与读取响应体的先后均保留。
- SkipMonitoring 仍只设置原 OpsSkipPassthroughKey；没有新增或改变 SLA 标记。父侧统一 HTTP 错误文件未改。
- gateway/forward.APIKeyPassthrough 接管原直通入口的准备/响应解释；平台网络交换、内部恢复、SSE 读取和流结束仍复用 upstream/anthropic.Executor。
- 原 anthropicPassthroughForwardInput 为 forward.APIKeyInput 的别名；旧字段与 ParsedRequest 引用保留。wire body 同步、上游服务标识、部分 usage、客户端断开和无新增 accepted 回调的边界保持。
- invalidNonStreamingJSONFailoverError 委托 forward.InvalidJSON，保留 502 健康状态、模型作用域、响应 Header 和原重试标记。
- 新 HTTP Adapter 为 anthropic_forward_error.go、anthropic_passthrough_headers.go。Header 过滤直接复用 egress / egress/provider，不引入旧 config shim。

## 明确保留的技术/健康投影

未强制拆分已经是纯技术投影的 buildUpstreamRequestAnthropicAPIKeyPassthrough、handleStreamingResponseAnthropicAPIKeyPassthrough、handleNonStreamingResponseAnthropicAPIKeyPassthrough、anthropicPassthroughExchangeOptions、anthropicStreamOptions、anthropicResponseOptions，以及协议 usage 解析委托。这些入口只向已迁 upstream 提供参数/单步能力。

handleRetryExhaustedSideEffects / handleFailoverSideEffects 继续作为已有健康命令调用 RateLimitService，不搬迁或改写账号领域规则。其它未迁消费者的 error_passthrough_runtime 兼容入口未改；本批新路径直接复用同一个匹配服务，没有第二份规则缓存或匹配算法。

## 装配与文件

原构造签名不变，不新增 app 字段/worker/Wire provider。新 Adapter 复用现有消息投影和 nativeAttemptActivity；不新增账号切换循环、取消规则、共享状态或资金动作。

本批精确 13 文件及 import：/tmp/s11-error-files.json。只编辑指定两个 service 文件及所属新核心/HTTP/Adapter/测试；未修改 Boole 的 openai_gateway_*、Lovelace 的固定执行契约、父级 HTTP 统一错误输出、Wire/gates/docs、Ent/SQL 或冻结资料。

## 验证

- 普通：58 pass，0 fail，0 skip，退出码 0。
- unit：75 pass，0 fail，0 skip，退出码 0。
- 新增最小 TestAnthropicErrorEntryRuleAndMonitoring，从旧生产入口覆盖普通/重试耗尽 × skip/keep 四个子用例，检查 HTTP 状态、安全消息、提交标记与原监控 key。
- 必要 race：按确认安排逐个精确顶层运行，保留内部并发和全部断言；结果 /tmp/s11-error-isolated-race/results.json。
- 新 forward 核心 staticcheck：0 issues，退出码 0。/tmp/s11-error-core-lint.log
- 13 文件 diff-check 无 whitespace 诊断。/tmp/s11-error-diff-check.json
- 命令/汇总：/tmp/s11-error-tests.json。父子事件与不同集合不可相加。

本次仅迁移与契约回归，没有历史问题审计。门禁夹具期间按父侧通知暂停依赖测试，没有修改 errorpolicy/rule.go 或临时 zz_s11_gate.go。多次并行代码编译中间态原日志保留在 /tmp/s11-error-isolated-race-compile-blocked* 及当前目录的 *.compile-blocked-*；它们没有执行测试，不能计为行为失败或通过。

## 父侧收尾

生产改绑已生效，无待应用补丁。父侧同步门禁和 Project Doc，重点为 gateway_error_policy.md#error_passthrough_rule_matching 与 anthropic_upstream.md#anthropic_native_execution 的实际执行归属；阶段全量验收仍由父侧完成。未提交、推送或切换分支。

## 按父侧要求交接稳定实现

本块实现已完整，生产入口已改绑，没有剩余文件/接口/构造待修改。保留的请求构造、流读取参数及健康命令是约定的技术/领域投影，不是未完成迁移。

普通 58、unit 75 条通过事件，无失败/跳过。独立 race 已执行 21 个顶层、34 条通过事件；尚未执行的两个顶层仅因其它子任务编译中间态受阻。按父侧最新指示停止依赖测试重试，以下命令在 backend 目录由父侧稳定集成后补验：

```bash
GOTOOLCHAIN=go1.27.0 go test -tags=unit -race -count=1 -json ./internal/service -run '^TestRetryLoop_ErrorPolicy_NoPolicy_OriginalBehavior$'
GOTOOLCHAIN=go1.27.0 go test -tags=unit -race -count=1 -json ./internal/service -run '^TestRetryLoop_ErrorPolicy_TempUnschedulable$'
```

本批没有修改 Boole/Lovelace/父侧禁止范围；不需要应用额外补丁或 Wire provider。精确文件和 import 仍见 /tmp/s11-error-files.json。

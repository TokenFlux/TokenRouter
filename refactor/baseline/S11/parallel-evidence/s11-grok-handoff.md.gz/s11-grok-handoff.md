# S11 Grok Responses / Composer / 观测交接

已迁移 service/openai_gateway_grok.go 的 forwardGrokResponses、describeGrokComposerImage、updateGrokUsageFromResponse、parseGrokQuotaSnapshot；旧签名保留为投影委托，当前生产调用已接通。不需要父侧再应用替换 JSON。

## 唯一生产实现

- gateway/provider/grokforward.Forward：账号类型和模型入口检查、Grok body/工具处理、Compact、缓存身份准备、取凭据、一次原生 Executor 调用、HTTP 错误决定和重试元数据、响应观察、搜索/图片用量向旧完成调用者的返回。
- DescribeImage：Composer 单图请求构造、原辅助请求 context 释放点、SingleExchange、错误/账号健康命令、描述解码与用量。没有绑定主会话提示缓存身份，也没有新增推理重试。
- ObserveResponse / ParseQuota：响应额度事实解析、按原时机标记型号、保存观测；无 Header 的成功仅调用原精确冷却恢复命令，不覆盖已有快照。
- gateway/httpapi/grok_forward_error.go：模型/工具前置拒绝的 HTTP 400 envelope，原 param 字段和无额外提交标记保持。
- service/grok_forward_execution_adapter.go、grok_forward_result_adapter.go、grok_observation_execution_adapter.go：逐能力绑定和显式值转换；新 provider 不引用旧 service/config/Gin，也不引用 OpenAI 具体 provider。

upstream/grok 的 ResponsesExecutor、ExchangeResponses、BodyCodec、工具与 ping 过滤、Compact/密文恢复、Composer 描述解码和响应关闭全部复用，没有修改上游算法。共用 OpenAI 流/非流读取仍调用 Boole 正在迁移的现有稳定方法委托，未修改其 forward/messages/passthrough 文件。

## 账号边界与装配

账号健康通过 Health/MarkTeam/ObserveSuccess 等窄命令调用既有唯一实现。updateGrokUsageSnapshotWithRateLimit、applyGrokAccountUpstreamError、rateLimitGrok 及相关账号规则保持原实现和原时机，未改账号领域判断、节流器、CAS 或持久化语义，也未另建状态。

原构造与方法签名均不变，无新 app 字段、Wire provider 或生命周期实例。Options.Enter 直接投影已有 nativeAttemptActivity，继续使用父侧共享 Operations；原平台取消策略、每次请求的临时 Adapter 和响应资源拥有关系保持。

全部 9 个文件与精确 import：/tmp/s11-grok-files.json。父侧同步 gateway/provider/grokforward、gateway/httpapi 和精确 service Adapter 的门禁；未编辑 .golangci.yml、Wire、docs/refactor、Ent/SQL 或其他任务文件。

## 验证证据

- 普通标签：指定的既有消费者测试均属 unit，命令退出 0 但 no tests to run；只计编译证据，不计行为通过。/tmp/s11-grok-target-normal.json
- unit：25 个顶层、30 个通过事件，0 失败、0 跳过，退出码 0。/tmp/s11-grok-target-unit.json
- unit race：按父侧确认安排，一次 go test -tags=unit -race -count=1 -run 精确一个顶层。最终结果见 /tmp/s11-grok-isolated-race/results.json；不降低测试内部并发或修改断言。
- 新 provider staticcheck：0 issues，退出码 0。/tmp/s11-grok-provider-lint.log
- 9 个新旧文件 diff-check 无 whitespace 诊断。/tmp/s11-grok-diff-check.json

测试覆盖本地实际 HTTP/SSE 调用与旧入口新实现：API Key/OAuth、客户端工具/namespace、Compact 回放和无过度匹配、末端重试失败、跨账号缓存身份、Free 工具缓存路线、Composer 图片描述、search usage、无 Header 恢复和池模式观测边界。未调用生产凭据，也未开展历史问题审计。

## 前一批 race 补验

原 Forward 转换集合失败涉及的 17 个顶层测试已逐个独立 race 通过（22 通过事件、无失败/跳过）。结果 /tmp/s11-forward-isolated-race/results.json；原并行集合 Gin 全局模式竞争失败日志仍完整保留。未修改测试内部 goroutine、断言或 Gin 设置。

## 父侧后续

本批生产改绑已完成，父侧负责门禁、文档及阶段全量验证。文档重点为 grok_upstream.md#grok_account_contract 与网关生命周期中的旧 Grok Responses/Composer 入口归属。未提交、推送或切换分支。

## 最终 race 与收尾结果

25 个 Grok 顶层逐个独立 race 全部退出码 0，共 30 个通过事件，无失败/跳过。中途三项被 Boole 正在写的 PassthroughPorts/import 编译中间态阻断，只重跑未执行项；原编译记录以 *.compile-blocked.json / before-resume-results.json 保留，没有修改对方文件。

本批删除了迁出后无消费者的旧 Composer 常量/私有请求体委托；平台 BodyCodec 仍拥有原 512 token 请求构造。最终 9 文件 diff-check 无 whitespace 诊断。综合验证索引 /tmp/s11-grok-tests.json。

本批已停止写入，生产调用接通，无待应用构造/字段/Wire 变更。父侧可统一收尾门禁、文档和阶段验收。

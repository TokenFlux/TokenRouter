# S11 通用 Forward 与转换链交接

已完成本次指定的五条服务入口：Forward、ForwardAsResponses、ForwardAsChatCompletions、ForwardCountTokens、AntigravityGatewayService.ForwardGemini。生产旧入口均已改绑，当前共享树可编译，不需要再应用 JSON 或改 handler。

## 原生实现

- `gateway/forward.Messages`：请求准备、账号映射与平台规范化、mimic 设置和指纹调用顺序、缓存/工具处理、错误与部分用量决定。平台交换仍只调用一次 `upstream/anthropic.Executor`；其同账号恢复与预算继续唯一实现。原重试资格/退避函数委托 `forward.ShouldRetry/ShouldFailover/RetryDelay`。
- `gateway/forward.AsResponses/AsChat`：请求转换、获取凭据、发送、健康策略结果解释和选择流/缓冲输出。Responses 在发送前解析 effort，Chat 仍在成功响应后解析，没有统一成另一时点。
- `ResponsesBuffered/ResponsesStreaming/ChatBuffered/ChatStreaming`：扫描事件推进、完整非流聚合、工具还原、usage 合并、原 TTFT/断开/终态语义；协议算法直接复用 `protocol/bridge`，时钟/随机源由现有适配入口投影，不安装共享状态。四个旧私有输出入口仅在 `gateway_forward_output_compat_test.go` 为原测试委托，生产不再保留第二份实现。
- `CountTokens/CountPassthrough`：无槽 HTTP 准入循环仍由父侧拥有，本批只迁服务执行。保留一次签名过滤重试、成功后回写最终 wire body、404 估算回退、原 body 上限及错误/成功 Header 差异；不增加消费或完成处理。
- `Gemini`：Antigravity Gemini 请求准备、原恢复调用、模型白名单、Google 错误决定、零 token 兼容及图片结果投影。`upstream/antigravity` 的 Retry/Recover/Executor 算法未改，未另建账号循环。
- `Mimic`：兼容端点的系统、metadata、消息缓存及工具改写流程。格式算法/实际设置和指纹读取留单步 Adapter。旧 systemRaw any 仅是既有 JSON string/array 兼容输入，未把任何旧业务实体传入 core。
- `gateway/httpapi.ForwardConversionOutput`：同步 SSE/JSON 输出、Flush、原错误 envelope 和 Header；直接依赖 `egress.CompiledHeaderFilter` / `egress/provider.WriteFilteredHeaders`，已删除 `util/responseheaders` import。

## 构造与门禁

无需变更任何原 provider/构造签名、应用字段或 Wire 生成。旧 GatewayService/AntigravityGatewayService 只在 `*_execution_adapter.go` 投影已有实例、凭据和逐次 I/O；没有迁整个 Service、缓存或锁。所有新核心只接受明确字段和窄端口，不 import service/repository/handler/model/domain/config、Gin、HTTP/SQL/Redis 或具体平台 Adapter。

`/tmp/s11-forward-files.json` 列出本批 28 文件及精确 import。父侧同步 gateway/forward 核心、gateway/httpapi 和这些精确 service Adapter 的 depguard；没有改动 .golangci.yml、app/wire、docs/refactor、SQL/Ent 或其它子任务文件。

核心调用传统服务的保留边界是单步能力及已迁模块入口：搜索模拟/Bedrock/API Key passthrough 分派、平台 wire 选项、受控凭据、健康决定和错误展示。原平台执行器仍负责唯一网络交换与响应关闭，GatewayService 的其它编排没有整体移包。

## 验证

统一 GOTOOLCHAIN=go1.27.0；全部在当前共享树执行，无临时覆盖生产文件。

- 普通定向：66 pass，0 fail，0 skip，退出码 0。
- 扩展 unit：96 pass，0 fail，0 skip，退出码 0。
- unit race：77 pass，19 fail，0 skip，退出码 1。不能记为通过；当前诊断均是既有原测试里的 Gin SetMode/IsDebugging 全局模式竞争。按用户边界只保留本次证据，不修夹具、不另行复现，也未降低并发掩盖它。日志 `/tmp/s11-forward-target-race.json` 及 `.log`。
- 删除无消费者旧私有包装、将四个输出名称迁到测试兼容文件后，相关 unit 补验 14 pass，0 fail，0 skip。
- 新 `gateway/forward` staticcheck：0 issues，退出码 0，`/tmp/s11-forward-core-lint.log`。
- 新旧本批文件 diff-check：28 文件无 whitespace 诊断，`/tmp/s11-forward-diff-check.json`。no-index 检查 exit 1 仅表示新文件差异。
- 测试汇总 `/tmp/s11-forward-tests.json`；事件含父子测试，集合重叠，不相加。

覆盖实际旧入口委托后的本地 HTTP/SSE 链：部分用量/静默终止、输出前与输出后 overloaded 状态、passthrough Header/body、OAuth 模型映射、cache usage、namespace/工具 JSON、compact SSE、effort、CountTokens 与 Antigravity 项目/模型/签名恢复、粘性限流和映射计费。

曾短暂遇到其它任务未使用 import、InputTokens 分组方法等编译中间态，只记录日志，未修改对应文件；最终普通/unit 已在它们稳定后通过。

## 父侧收尾

本批无待应用绑定，生产调用已经接通。父侧处理门禁、Project Doc 与阶段全量验证；文档重点是 `gateway_request_lifecycle.md#protocol_conversion_boundary`、`anthropic_upstream.md#anthropic_native_execution` 和 Antigravity 原生入口执行归属。不得将上述测试夹具 race 的失败集合计为通过。未提交、推送或切换分支。

补充静态检查说明：删除本批无消费者旧常量/私有包装后，完整 service unused 检查遇到 Boole 正在迁移的 gateway/provider/openaiforward/messages.go 未完成类型/import，中止于 typecheck。没有改对方文件，也不声称该完整检查通过；日志 /tmp/s11-forward-unused-final.log。新核心 staticcheck 的独立零诊断结果仍有效。

## 父侧确认的独立 race 补验

按约定一次 go test -tags=unit -race -count=1 -run 精确一个顶层测试，不改变测试内部 goroutine 或断言。17 个顶层、22 个通过事件，全部退出码 0，无失败/跳过，未出现单顶层内部竞争。结果与逐命令日志：/tmp/s11-forward-isolated-race/results.json。原并行集合 19 个失败仍保留，不改写为通过。首次因并行任务编译中间态未执行测试的记录归档 /tmp/s11-forward-isolated-race-compile-blocked/。

# S11 Compact 迁移交接

实现已完成，源文件停止写入；共享工作区直接包含以下变更，不需应用补丁。

## 生产绑定与所有权

- `service/openai_compact_stream_bridge.go` 委托 `gateway/httpapi`。原客户端 stream 标记键、输出接管顺序和 `MarkOpsStreamError` 时点保留。
- `gateway/compact.StreamPayload` 唯一拥有 unary Compact → `response.output_item.done` / `response.completed` 的转换与 usage 可解析检查。HTTP 注入 ID 生成器，仅缺失合法 ID 时调用。
- `gateway/httpapi/compact_keepalive.go` 唯一持有原心跳 mutex、writer、stop 和已写字节数；原 service Start/Stop/AdjustedWrittenSize 入口只委托。同一状态同时用于桥接停拍和响应大小扣除，不增加全局实例或另一个 worker。
- `gateway/compact.Recovery` 拥有恢复条件、账号专用规则优先与全局延迟读取、一次同账号改模、失败 envelope 规范化及已确定恢复后的效果顺序。
- `service/openai_compact_execution_adapter.go` 的 Models/RetryEffects 仅投影旧账号与配置、调用唯一协议分类与模型改写、释放旧响应、提交观测。保留旧日志名称/文本和原 Header/状态码。
- 旧 `openAICompactFallbackSignal` 为 `errors.As` 和 Boole 现有私有字段访问保留兼容载体；Error 与决策全部委托原生值/规则，无第二份状态或算法。不修改 Boole 的 `openai_gateway_forward.go` 或现有执行 Adapter。
- 两项直接构造私有 writer 的原测试迁至 HTTP 包，全部原断言保留；service 的生产消费者测试继续验证旧签名已接新实现。

## 构造与接入

无新增 app/Wire provider，无现有构造签名调整。生产调用已由旧签名接通，父侧无需补接主链。

若父侧进一步直接替换原 HTTP 兼容调用，稳定入口（import `github.com/TokenFlux/TokenRouter/internal/gateway/httpapi`）：

- `MarkOpenAICompactClientStream(*gin.Context)` / `OpenAICompactClientWantsStream(*gin.Context)`
- `StartOpenAICompactSSEKeepalive(*gin.Context,time.Duration) func()`（检查原标记）
- `StartOpenAISSEKeepalive(*gin.Context,time.Duration) func()`（既定 SSE 透传入口）
- `StopOpenAICompactSSEKeepaliveCommitted(*gin.Context) bool`
- `OpenAICompactKeepaliveAdjustedWrittenSize(*gin.Context) int`
- `WriteOpenAICompactSSEBridge(*gin.Context,int,[]byte,CompactStreamErrorObserver) bool`
- `WriteOpenAICompactSSEFailureMessage(*gin.Context,int,string,string,CompactStreamErrorObserver)`
- `CompactFallbackErrorResponse(*http.Response,*compact.Failure) (*http.Response,[]byte)`

`CompactStreamErrorObserver` 为 `func(*gin.Context,string,string,int)`，按现有 `MarkOpsStreamError` 绑定；不要改为新增 SLA 分类。未要求父側做此进一步调用清理即可生产使用。

核心精确 import：`github.com/TokenFlux/TokenRouter/internal/gateway/compact`。新核心实际依赖 upstream 根契约/纯错误提取、pkg/logredact、gjson/sjson 与纯标准库；无具体平台、旧 service/config/Gin/HTTP/SQL/Redis 反向依赖。全部文件精确 import 和摘要见 `/tmp/s11-compact-files.json`；门禁由父侧统一处理。

## 修改文件

- `backend/internal/gateway/compact/fallback.go`（new）
- `backend/internal/gateway/compact/observation.go`（new）
- `backend/internal/gateway/compact/recovery_test.go`（new）
- `backend/internal/gateway/compact/stream.go`（new）
- `backend/internal/gateway/httpapi/compact_fallback.go`（new）
- `backend/internal/gateway/httpapi/compact_keepalive.go`（new）
- `backend/internal/gateway/httpapi/compact_keepalive_test.go`（new）
- `backend/internal/gateway/httpapi/compact_stream_bridge.go`（new）
- `backend/internal/service/openai_compact_fallback.go`（modified）
- `backend/internal/service/openai_compact_sse_keepalive.go`（modified）
- `backend/internal/service/openai_compact_stream_bridge.go`（modified）
- `backend/internal/service/openai_compact_sse_keepalive_test.go`（modified）
- `backend/internal/service/openai_compact_execution_adapter.go`（new）
- `backend/internal/service/openai_compact_http_compat_test.go`（new）

## 验证与剩余验收

- 普通：原 service 消费者 65 pass；新核心/HTTP 6 pass，共 71 条事件。
- unit：原 service 消费者 66 pass；新核心/HTTP 6 pass，共 72 条事件。
- 上述均 exit 0，无失败/跳过；事件包含父子测试。
- 心跳共享状态及两条恢复主链按精确顶层逐次 race：20 条命令全部 exit 0，25 pass / 0 fail / 0 skip。保留内部 goroutine 和全部原断言。结果在 `/tmp/s11-compact-isolated-race/results.json`，完整汇总 `/tmp/s11-compact-tests.json`。本块无待验命令。
- 新 core 与 HTTP 源文件 govet/ineffassign/staticcheck 均 exit 0、0 issues：`/tmp/s11-compact-core-lint.log`、`/tmp/s11-compact-http-lint.log`。
- 14 文件 tracked/new diff whitespace 检查通过，见 `/tmp/s11-compact-diff-check.json`。
- 无新增历史问题，无 SQL/Ent/Wire/gate/docs/refactor 改动；全量验证、文档和门禁归父側。

前一错误策略块两个 race 命令仍交父側，不在本块重跑（当时仅共享树编译中间态，未执行到行为）：

```sh
GOTOOLCHAIN=go1.27.0 go test -tags=unit -race -count=1 -json ./internal/service -run '^TestRetryLoop_ErrorPolicy_NoPolicy_OriginalBehavior$'
GOTOOLCHAIN=go1.27.0 go test -tags=unit -race -count=1 -json ./internal/service -run '^TestRetryLoop_ErrorPolicy_TempUnschedulable$'
```

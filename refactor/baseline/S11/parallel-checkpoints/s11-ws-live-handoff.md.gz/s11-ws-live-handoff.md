# S11 WS/Live 子任务最终交接（共享工作区，未提交）

## 结果

上一轮未完成的两个 WS 主编排函数已继续迁完，生产兼容入口已调用新核心；不再把辅助状态迁移计作主编排完成。

- `gateway/ws.IngressSession.Run`：HTTP bridge 与 ctx_pool 的完整逐轮循环、BeforeRequest/BeforeTurn、时间快照、硬 previous_response 亲和、strict 比较、失效密文处理、当前轮重放、一次恢复、账号连接租约 pin/unpin/Release、AfterTurn 和下一轮读取。
- `gateway/ws.RequestNormalizer.Normalize`：完整逐轮规范化顺序、请求模型缺省、身份 metadata、额外工具模型、图片策略、Fast/effort 处理和成功后的会话模型提交。
- `gateway/ws.RelayTurn`：ctx_pool 逐帧读写、先 usage/Cyber 观察后失败判断、TTFT、终态、模型/工具恢复、下游断连排水、图片/重放采集及结果输出。
- `gateway/ws.PassthroughSession.Run`：首帧处理、单次凭据恢复、双向 relay、逐轮过滤/快照、终态写入屏障、模型恢复、事件观察、完成回调、超时与关闭映射。底层 relay 算法仍调用唯一 upstream/openai/wsrelay 实现。
- Live 维持前批迁移结果：创建尝试、租约接替、保存/查询、B06、sideband、observer、关闭认领与零费用事实均由 gateway/live 拥有；HTTP 由 gateway/httpapi.LiveHandler 拥有。

两个旧入口现在仅委托：
- `service.ProxyResponsesWebSocketFromClient` → 明确技术装配 → `IngressSession.Run`（passthrough 分支调用下述入口）。
- `service.proxyResponsesWebSocketV2Passthrough` → `PassthroughSession.Run`。

旧 service Adapter 只保留当前选中账号的执行凭据、Header/TLS、配置投影、单次账号规则/平台 codec 调用、单次拨号/池操作与诊断投影。网关循环、恢复次数、快照、输出和完成时序不再藏在旧 Adapter 中。无泛型或 any 携带旧实体进入核心；JSON 动态对象只用于协议报文。

## 父任务接入

没有修改 `openai_gateway_service.go`、`openai_gateway_handler.go`、app/wire、depguard、docs、refactor 或 upstream 算法。现有构造签名和生命周期绑定继续可用；不需要额外完成实例、字段或 Wire 生成。

父侧已完成的 AfterTurn / CompletionOpenAIInput / completionRuntime().Record 通过原 hooks 继续工作。`wsIngressHooks` 逐字段把新 `TurnCapture/ForwardResult` 转为旧回调形状，不重复结算，不变更 worker budget。

供父侧新 ResponsesWebSocket HTTP 入口使用的原生契约：

```go
// import gatewayws "github.com/TokenFlux/TokenRouter/internal/gateway/ws"
(*IngressSession).Run(ctx context.Context, firstMessage []byte) error
(*PassthroughSession).Run(ctx context.Context, client ClientSocket, firstMessage []byte) error
```

关键类型：IngressHooks、PassthroughHooks、TurnCapture、ForwardResult、ClientPayload、IngressState、ClientSocket、ConnLease/StreamLease、ReplayCodec、IngressPort/PassthroughPort。全部字段明确，不接收 Gin、HTTP、完整配置或旧实体。具体平台连接由 typed FrameConn 适配。

父任务仍负责自己已保留的 ResponsesWebSocket handler 准入/租约/完成绑定。原 handler 调用旧 service 入口已能进入新核心；如改为直接 app 绑定，可复用上述接口与本次 service 中的逐字段投影，无须重新实现循环。

Live 直接路由绑定：

```go
liveHandler := existingOpenAIGatewayHandler.NewLiveHTTPHandler()
// 使用 liveHandler.Live / liveHandler.LiveSideband
```

旧 Live 方法已委托此实现。独立原生构造为 `gateway/httpapi.NewLiveHandler(LiveHTTPPorts)`。

## 唯一状态与适配边界

- WS 会话状态、turn queue、atomic usage metadata、输出期限、preemption registry 和 Live observer 状态只保留一份。
- 旧 service 的 observer mutex/stopped/cancels/WaitGroup 通过 gateway/live.ObserverState 传引用；已有 StopLiveObservers 不需改字段。
- 技术 ConnLease/FrameConn 和纯协议 PreviousTurn 比较器是窄资源/codec 端口，不是旧 Account/Service 的不透明包装。
- 完成结果投影包含全部旧 ForwardResult 字段（含媒体、warning、response headers、replay 序列），没有为简化接口丢字段。
- 原测试使用的 helper 形状移到 `openai_ws_s11_compat_test.go`，只委托同一核心，没有第二份运行时算法。

## 文件与门禁

全部 48 个本子任务修改文件和逐文件精确 import：`/tmp/s11-ws-live-files.json`。

新核心额外依赖只有同级 gateway/session、protocol/openai、protocol、scheduler、gateway/modeltrace、routing/modelmap、gjson/sjson/uuid 及所需标准库；没有旧 service/repository/handler/domain/model/config、Gin、HTTP/SQL/Redis 或具体 upstream import。

新增 service Adapter 文件应按实际 import 精确登记，不能继承目录豁免：
- openai_ws_ingress_adapter.go
- openai_ws_ingress_execution_adapter.go
- openai_ws_result_adapter.go
- openai_ws_passthrough_execution_adapter.go
- openai_ws_relay_adapter.go
- openai_ws_stream_adapter.go
- openai_ws_request_adapter.go

父任务统一更新 Project Doc：OpenAI 协议/WS 章节、网关生命周期与输出/完成边界、`upstream_cyber_policy` 代码锚点现已在新 stream 核心；保持当前 S09/S11 新旧技术适配事实，不把 Adapter 宣称全部删除。

## 验证

- `/tmp/s11-ws-orchestration-final-race.json`：最终主编排定向 unit race **245 pass、1 既有 skip、0 fail**，命令退出码 0。
- `/tmp/s11-ws-native-all-unit.json`：主编排和策略定向 unit **211 pass、1 既有 skip、0 fail**。
- `/tmp/s11-ws-orchestration-normal.json`：新核心与 service 普通测试 **235 pass、1 既有 skip、无行为失败**；整个命令退出码 1，因为父侧 handler Messages 正在变更（FirstSelectionFailure 签名、isClaudeCodeClient、未使用 err）。不能把该命令记为全组通过。
- `/tmp/s11-native-live-ws-final.json`：此前新增核心完整 race **5 pass、无失败/跳过**（B06、关闭认领、停止等待、turn 屏障和副本）。
- 48 个本子任务文件（含新增）的 diff --check 均通过。未运行全仓测试、Wire 或 Ent。
- `unused` 专项对照发现迁移后 7 个旧 WS 私有委托无消费者，已删除。其它父侧迁移中的 unused 诊断未修改，日志 `/tmp/s11-ws-unused-complete.log`；该日志不是阶段 lint 验收。

唯一保留 skip：原 `TestOpenAIGatewayService_ProxyResponsesWebSocketFromClient_PassthroughBridgeBoundaries/other_event_type`。

## 当次偶然观察与中间失败

`/tmp/s11-ws-live-final-race.json` 是之前扩大到 Turn 名称筛选时捕获的旧 `openai_compat_model_test.go` 并行 gin.SetMode 竞争。只保存当次证据，未追加复现或修复，不能记为通过。

中间编译错误及修复前日志保留在 /tmp/s11-ws-*.json/log。自引入的字段名、helper 委托、接口和格式错误已解决；遇到父侧媒体/HTTP 同时迁移造成的暂态错误时未改他人文件。

本子任务不提交、不推送、不切分支；没有历史问题扩展、SQL/cache 协议变更或金额行为修改。

## 当前共享树接口稳定性复验

- `/tmp/s11-ws-stable-interface-race.json`：当前共享树下再次取得 **245 pass、1 既有 skip、0 fail**，退出码 0；与前述集合重叠，不累加。
- `gateway/httpapi.WSClientFrames{Conn: wsConn}` 现在完整实现 `gateway/ws.ClientSocket`（Read/Write/Close/CloseNow），带编译期断言。旧 passthrough 委托已使用同一实现，删除 service 中重复的纯帧转换类型。
- 父侧创建原生 HTTP handler 可直接复用该帧适配，不需要再次包装或改变取消行为。两个 Run 接口、hooks 与结果投影均保持不变。
- 本次补充只涉及 WS 专属适配文件；没有修改父侧 AfterTurn/完成实例、Messages 或 ResponsesWebSocket 大 handler。
- `/tmp/s11-ws-shared-client-race.json`：共用 HTTP 帧适配接入后的定向 race **59 pass、1 既有 skip、0 fail**，退出码 0。


## S11.5 入站 ResponsesWebSocket 补充交接

本批已完成前置准入、入站连接租约、升级、首帧、账号尝试循环及每 turn 调度/资金/审核/完成编排。未编辑 `handler/openai_gateway_handler.go` 或 `handler/session_isolation.go`。

### 父侧应用

- `/tmp/s11-ws-http-entry-replacement.json` 提供完整方法、辅助函数/变量委托、精确 import 和原声明 SHA256。请按声明替换，不用 overlay 整文件覆盖父侧大文件。
- 主方法调用 `h.NewResponsesWSHTTPHandler().ResponsesWebSocket(c)`。构造返回 `*gateway/httpapi.ResponsesWSHandler`；可在装配中构造一次，以其 `.ResponsesWebSocket` 直接绑定原路由。
- 无新 handler 字段、service 字段、共享状态或 Wire provider；复用现有 concurrencyHelper、完成实例、账号服务与配置预算。
- `handler/session_isolation.go` 的两条 WS 输出辅助应应用 JSON 内委托，HTTP 算法唯一归新 Adapter；其中 HTTP/SSE 的其他函数保持父侧实现。
- 新 core `gateway/ws.RunEntry(ctx, EntryPorts, EntryInput, ClientSocket, []byte)` 拥有循环和所有 hook 时序；`openAIWSEntryAdapter`/`openAIWSEntryTarget` 仅逐能力投影。未把旧 handler 整体包进 execute 回调。
- 完成任务在提交前调用 CompletionOpenAIInput，闭包只捕获完成输入、Recorder 和日志观察函数；沿用完成前后模型链、pricingAt 和图片失败资格。

### 本批修改

新增：
- backend/internal/gateway/ws/entry.go
- backend/internal/gateway/ws/entry_contract.go
- backend/internal/gateway/ws/entry_rules.go
- backend/internal/gateway/httpapi/responses_ws.go
- backend/internal/gateway/httpapi/ws_errors.go
- backend/internal/handler/openai_ws_http_adapter.go

延续已归本专项的改动：
- backend/internal/gateway/ws/preemption.go：公共抢占判断唯一实现。
- backend/internal/service/openai_ws_session_preemption.go：原判断委托。
- backend/internal/service/openai_ws_result_adapter.go：公开 native/旧结果投影，复用现有唯一转换。

全部 WS/Live 专项 54 文件及当前精确 import 在 `/tmp/s11-ws-live-files.json`，本批新增六文件已包含。父侧同步 depguard、迁移账本与 Project Doc（gateway_request_lifecycle/openai_upstream 中“完整入站 WS 留旧网关”的描述需要随替换应用更新）。未改 docs/refactor/depguard/Wire。

### 验证

使用 `/tmp/s11-ws-http-overlay.json` 将 JSON 声明在仓库外应用到当前大文件副本。Go 定向测试执行新 HTTP + native RunEntry + 已迁 native WS 主循环，包含本地真实 HTTP/WebSocket 交换，不是只编译端口。

- 普通：46 pass，0 fail，0 skip，退出码 0。
- unit：50 pass，0 fail，0 skip，退出码 0。
- unit race：50 pass，0 fail，0 skip，退出码 0。
- 事件包含父子测试，三集合重叠，不相加。
- 覆盖升级、容量拒绝、租约 backend 故障、首帧超时、early return/Accept 失败释放、previous-response 类型与粘性边界、首帧审核、UA/effort 完成记录、凭据失败切号/取消、输出前超时切换、Cyber 多轮状态，以及关闭/失败反馈辅助。
- 完整命令与汇总：`/tmp/s11-ws-http-tests.json`；日志分别 `/tmp/s11-ws-http-entry-{normal,unit,race}.json` 和对应 stderr。
- 54 文件 tracked/new diff-check 无 whitespace 诊断；未跟踪文件的 no-index 检查 exit 1 仅表示新增差异。证据 `/tmp/s11-ws-http-diff-check.json`。
- 核心没有 service/config/Gin/HTTP/SQL/Redis/具体 Adapter import；新 HTTP 不引用 service/config。
- 未开展历史问题审计或追加修复，也未运行全仓测试/生成命令。

### 尚需父侧

应用 JSON、将路由直接绑定原生 Handler、门禁/文档及串行阶段验收。应用后旧 ResponsesWebSocket 即唯一委托；当前工作树原大方法仍未替换，这是共享写入约定。

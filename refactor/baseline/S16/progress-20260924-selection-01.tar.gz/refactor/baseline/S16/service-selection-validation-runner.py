from pathlib import Path
import subprocess,os,json,time,collections,hashlib
root=Path('/Users/daodaoneko/GolandProjects/TokenRouter');out=root/'refactor/baseline/S16';env=os.environ.copy();env['GOTOOLCHAIN']='go1.27.0'
packages=['./internal/gateway/...','./internal/service/...','./internal/app/...','./internal/scheduler/...']
checks=[('build',['go','build','./...'])]
for tag in ['normal','unit','integration']:
 cmd=['golangci-lint','run','--timeout=15m','--max-same-issues=0','--max-issues-per-linter=0']
 if tag!='normal':cmd+=['--build-tags='+tag]
 checks.append(('lint-'+tag,cmd+packages))
for tag in ['normal','unit','integration']:
 cmd=['go','test','-count=1','-json']
 if tag!='normal':cmd+=['-tags='+tag]
 if tag=='integration':cmd+=['-p=4']
 checks.append(('tests-'+tag,cmd+packages))
checks += [('race-owner',['go','test','-count=1','-json','-race','-tags=unit','./internal/gateway/provider/selection','./internal/gateway/provider','./internal/gateway/requeststate']),('race-execution',['go','test','-count=1','-json','-race','-tags=unit','./internal/service','-run','Test(OpenAIStreaming(PostOutput|TerminalAndClient|PassthroughPostOutput)|HandleOpenAITransientError_Canonical|NewOpenAIGatewayService_Initializes)']),('race-app',['go','test','-count=1','-json','-race','-tags=unit','./internal/app','-run','Test(AccountRuntimeBlockBinding|SchedulerSharedState|Selection|GatewayBackgroundTasks|OpenAI|Chat|Gateway|Qoder|Message|Gemini)']),('race-storage',['go','test','-count=1','-json','-race','-tags=integration','-p=4','./internal/scheduler/rediscache/...'])]
report=out/'service-selection-final-validation.json';rows=[]
for name,cmd in checks:
 log=out/('service-selection-final-'+name+('.json' if '-json' in cmd else '.log'));start=time.time();row={'name':name,'command':cmd,'GOTOOLCHAIN':'go1.27.0','log':str(log.relative_to(root)),'status':'running'};rows.append(row);report.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('START',name,flush=True)
 with log.open('w') as f:result=subprocess.run(cmd,cwd=root/'backend',env=env,stdout=f,stderr=subprocess.STDOUT)
 row.update(status='finished',exit_code=result.returncode,seconds=round(time.time()-start,3))
 if '-json' in cmd:
  events=[]
  for line in log.open():
   try:events.append(json.loads(line))
   except ValueError:pass
  row['events']=dict(collections.Counter(x['Action'] for x in events if x.get('Test') and x['Action'] in ['pass','fail','skip']))
  row['failed_tests']=[{'package':x.get('Package'),'test':x['Test']} for x in events if x.get('Test') and x['Action']=='fail']
 report.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('END',name,row,flush=True)
 if result.returncode:raise SystemExit(result.returncode)

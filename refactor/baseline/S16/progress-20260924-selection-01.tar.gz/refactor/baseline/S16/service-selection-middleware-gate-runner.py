from pathlib import Path
import tempfile,shutil,subprocess,json,os,time
r=Path('/Users/daodaoneko/GolandProjects/TokenRouter');out=r/'refactor/baseline/S16';module='github.com/TokenFlux/TokenRouter';rows=[];env=os.environ.copy();env['GOTOOLCHAIN']='go1.27.0'
cases=[('middleware-native-selection', 'internal/server/middleware/openai_fast_policy_forwarding_test.go', 'internal/gateway/provider/selection', False), ('middleware-no-old-child', 'internal/server/middleware/openai_fast_policy_forwarding_test.go', 'internal/service/child', True)]

root=Path(tempfile.mkdtemp(prefix='tokenrouter-s16-gates-'))
try:
 for name,source,dependency,reject in cases:
  fixture=root/name;fixture.mkdir();(fixture/'go.mod').write_text('module '+module+'\n\ngo 1.27.0\n');shutil.copyfile(r/'backend/.golangci.yml',fixture/'.golangci.yml')
  for package in ['internal/gateway/provider/selection','internal/gateway/testkit','internal/routing','internal/gateway/httpapi/testkit','internal/gateway/httpapi/testkit/private','internal/gateway/session','internal/scheduler','internal/scheduler/policy','internal/apikey','internal/account/provider','internal/account/provider/private','internal/app','internal/service','internal/service/child','internal/handler','internal/config','internal/account','internal/gateway','internal/gateway/httpapi','internal/gateway/requeststate','internal/protocol/openai','internal/account/postgres','internal/account/private','internal/gateway/provider','internal/repository','internal/upstream/openai','internal/upstream/grok']:
   path=fixture/package;path.mkdir(parents=True,exist_ok=True);(path/'fixture_base.go').write_text('// \u4e34\u65f6\u95e8\u7981\u5939\u5177\uff0c\u4e0d\u542b\u4e1a\u52a1\u5b9e\u73b0\u3002\npackage '+path.name+'\n')
  if dependency=='github.com/redis/go-redis/v9':
   local=fixture/'redis-stub';local.mkdir();(local/'go.mod').write_text('module github.com/redis/go-redis/v9\n\ngo 1.27.0\n');(local/'redis.go').write_text('package redis\n')
   with (fixture/'go.mod').open('a') as f:f.write('\nrequire github.com/redis/go-redis/v9 v9.0.0\nreplace github.com/redis/go-redis/v9 => ./redis-stub\n')
  dep=module+'/'+dependency if dependency.startswith('internal/') else dependency
  p=fixture/source;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('// \u9a8c\u8bc1\u5b9e\u9645\u95e8\u7981\u7684\u6587\u4ef6\u4e0e import \u8fb9\u754c\u3002\npackage '+p.parent.name+'\n\nimport _ "'+dep+'"\n')
  for tag in ['normal','unit','integration']:
   log=out/('service-selection-middleware-boundary-gate-'+name+'-'+tag+'.log');cmd=['golangci-lint','run','--enable-only=depguard','--timeout=5m','--max-same-issues=0','--max-issues-per-linter=0']
   if tag!='normal':cmd+=['--build-tags='+tag]
   cmd+=['./...'];row={'case':name,'tag':tag,'source':source,'import':dep,'expect_rejection':reject,'command':cmd,'log':str(log.relative_to(r)),'status':'running'};rows.append(row);report=out/'service-selection-middleware-boundary-gates.json';report.write_text(json.dumps(rows,indent=2)+'\n')
   with log.open('w') as stream:result=subprocess.run(cmd,cwd=fixture,env=env,stdout=stream,stderr=subprocess.STDOUT)
   output=log.read_text();matched=("import '"+dep+"' is not allowed") in output
   ok=(result.returncode!=0 and matched) if reject else result.returncode==0
   row.update(status='finished',exit_code=result.returncode,matched_import_diagnostic=matched,contract_passed=ok);report.write_text(json.dumps(rows,indent=2)+'\n');print(name,tag,ok,flush=True)
   if not ok:raise RuntimeError(name+'/'+tag+' unexpected gate result')
finally:
 shutil.rmtree(root)

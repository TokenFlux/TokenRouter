from pathlib import Path
import subprocess,os,json
r=Path('/Users/daodaoneko/GolandProjects/TokenRouter');out=r/'refactor/baseline/S16';env=os.environ|{'GOTOOLCHAIN':'go1.27.0'}
packages=['./internal/gateway/provider/selection','./internal/scheduler','./internal/scheduler/rediscache','./internal/gateway/requeststate','./internal/app','./internal/gateway/provider','./internal/gateway/httpapi','./internal/routing','./internal/service','./internal/upstream/openai','./internal/upstream/openai/liveattestation','./internal/web','./cmd/server','./tests/integration']
rows=[]
for name,flags,extra in [('normal',[],{}),('unit',['-tags=unit'],{}),('integration',['-tags=integration'],{}),('wireinject',['-tags=wireinject'],{}),('embed',['-tags=embed'],{}),('e2e',['-tags=e2e'],{}),('darwin',[],{'GOOS':'darwin','GOARCH':'arm64'}),('linux',[],{'GOOS':'linux','GOARCH':'amd64','CGO_ENABLED':'0'})]:
 cmd=['go','list','-e','-json',*flags,*packages];p=subprocess.run(cmd,cwd=r/'backend',env=env|extra,capture_output=True,text=True);text=p.stdout;decoder=json.JSONDecoder();values=[]
 while text.strip():
  text=text.lstrip();v,end=decoder.raw_decode(text);text=text[end:];values.append({k:v[k] for k in ['ImportPath','GoFiles','CgoFiles','IgnoredGoFiles','TestGoFiles','XTestGoFiles','Error'] if k in v})
 unexpected=[v['Error'] for v in values if 'Error' in v and 'build constraints exclude all Go files' not in v['Error'].get('Err','')]
 row={'unexpected_errors':unexpected,'name':name,'command':cmd,'environment':extra,'exit_code':p.returncode,'packages':values,'stderr':p.stderr,'behavior_verification':False};rows.append(row)
 (out/'service-selection-owner-build-selection.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
 print(name,p.returncode,flush=True)
 if p.returncode or unexpected:break
